<div class="contents-area">

        <div class="row">
            <div class="col-sm-3">
                <div class="title-box bg-secondary ico-box icon-browser">
                    <span class="num-bx">01.</span>
                    <div class="title-1">
                        <h6>Address</h6>
                        <h4 class="text-uppercase">Our Location</h4>
                    </div>
                    <a href="#" class="readmore"><i class="fa fa-plus"></i>Get Direction</a>
                </div><!-- /title-box -->
            </div>

            <div class="col-sm-6">
                <div class="box bg-grey">
                    <div class="address-box">
                        <div class="iconic"><i class="icon icon-location"></i></div>
                        <div class="text">
                            <div class="title-2"><h5>Address</h5></div>
                            <p>Anand : F-12, Triveni Arcade, Vidyanagar Road, Anand - 388001</p>
							<p>Surat : 312, Polaris Commercial Mall, Parvat Patiya, Surat - 395010</p>
                        </div>
                    </div><!-- /info-box -->
                </div><!-- /box -->
            </div>

            <div class="col-sm-3">

                <div class="title-box bg-primary ico-box icon-phone-o">
                    <span class="num-bx">02.</span>
                    <div class="title-1">
                        <h6>Call Now</h6>
                        <h4 class="text-uppercase">Touch with us</h4>
                    </div>
                    <a href="#" class="readmore"><i class="fa fa-plus"></i>Call us now</a>
                </div><!-- /title-box -->

            </div>
        </div><!-- /row -->

        <div class="row">
            <div class="col-sm-6">
                <div class="box box-dh bg-white">
                    <div class="contact-box">
                        <h4 class="text-uppercase">Contact us</h4>
                        <div id="message"></div>
                        <form id="contactform_forms" class="contact-form checkout-form" action="#" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group"><input id="contact_name" name="contact_name" type="text" class="form-control" placeholder="Name*"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group"><input id="contact_email" name="contact_email" type="text" class="form-control" placeholder="Email Address*"></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group"><input id="contact_subject" name="contact_subject" type="text" class="form-control" placeholder="Subject"></div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group"><input id="contact_website" name="contact_website" type="text" class="form-control" placeholder="Website"></div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group"><textarea id="contact_message" name="contact_message" class="form-control" placeholder="Message"></textarea></div>
                                </div>
                            </div>
                            <input type="submit" value="Send Now" class="btn btn-success">
                        </form>
                    </div><!-- /info-box -->
                </div><!-- /box -->
            </div>
            <div class="col-sm-6">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="title-box bg-primary ico-box icon-envelope-o">
                            <span class="num-bx">03.</span>
                            <div class="title-1">
                                <h6>Mail Now</h6>
                                <h4 class="text-uppercase">Email Address</h4>
                            </div>
                            <a href="#" class="readmore"><i class="fa fa-plus"></i>Mail us now</a>
                        </div><!-- /title-box -->
                    </div>
                    <div class="col-sm-6">
                        <div class="box bg-grey">
                            <div class="address-box">
                                <div class="iconic text-primary"><i class="icon icon-phone"></i></div>
                                <div class="title-2 title-2-primary">
                                    <h5>Touch with us</h5>
                                </div>
                                <p><a href="tel:+918866220223">+91 886 622 0223</a></p>
                                <p><a href="tel:+918155010101">+91 815 501 0101</a></p>
                            </div><!-- /address-box -->
                        </div><!-- /box -->
                    </div>

                    <div class="col-sm-6">
                        <div class="box bg-grey">
                            <div class="address-box">
                                <div class="iconic text-primary"><i class="icon icon-envelope"></i></div>
                                <div class="title-2 title-2-primary">
                                    <h5>Email us now</h5>
                                </div>
                                <p><a href="mailto:phoenix8155@gmail.com">phoenix8155@gmail.com</a></p>
                                
                            </div><!-- /address-box -->
                        </div><!-- /box -->

                    </div>
                    <div class="col-sm-6">
                        <div class="box">
                            <div id="map-canvas"></div>
                        </div><!-- /title-box -->
                    </div>

                </div>
            </div>
        </div><!-- /row -->

    </div><!-- /contents-area -->
<!-- google map script --> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB7z3qSfW7_1ArWHGs69jHLbLw-jOOGwuk"></script>
<script>
    function initialize() {
      var location = new google.maps.LatLng(22.5509376,72.933376);
      var mapOptions = {
        center: location,
        scrollwheel: false,
        disableDefaultUI: true,
        zoom: 14,
        styles: [   
            {       featureType:'water',        stylers:[{color:'#c3c3c3'},{visibility:'on'}]   },
            {       featureType:'landscape',        stylers:[{color:'#f2f2f2'}] },
            {       featureType:'road',     stylers:[{saturation:-100},{lightness:25}]  },
            {       featureType:'road.highway',     stylers:[{visibility:'simplified'}] },
            {       featureType:'road.arterial',        elementType:'labels.icon',      stylers:[{visibility:'off'}]    },
            {       featureType:'administrative',       elementType:'labels.text.fill',     stylers:[{color:'#444444'}] },
            {       featureType:'transit',      stylers:[{visibility:'off'}]    },
            {       featureType:'poi',      stylers:[{visibility:'off'}]    }]              
      };
      var mapElement = document.getElementById('map-canvas');
      var map = new google.maps.Map(mapElement, mapOptions);
    }
    google.maps.event.addDomListener(window, 'load', initialize);
</script>