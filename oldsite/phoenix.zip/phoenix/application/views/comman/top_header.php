<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>PHOENIX BINARY SYSTEM</title>

<link href="<?=asset_path()?>css/font-awesome.css" rel="stylesheet">
<link href="<?=asset_path()?>css/bootstrap.css" rel="stylesheet">
<link href="<?=asset_path()?>css/style.css" rel="stylesheet">
<link href="<?=asset_path()?>css/color.css" rel="stylesheet">
<link href="<?=asset_path()?>css/owl.carousel.css" rel="stylesheet">
<link href="<?=asset_path()?>css/responsive.css" rel="stylesheet">


</head>

<body>

<div class="pagewrap">
    
<div class="container">
    <div class="main-nav-bar">
        <button type="button" class="navbar-toggle navbar-toggle-mb" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
            <span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </span>
        </button><!-- /navbar-toggle -->
        <button type="button" class="navbar-toggle navbar-toggle-dt">
            <span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </span>
        </button><!-- /navbar-toggle -->
        <div class="logo logo_top_margin"><img src="<?=asset_path()?>/images/resource/phoenix_logo.png"></div>
        <div class="tp-control">
            <ul class="control-list">
                <li><span><a href="https://www.facebook.com/phoenixbinarysystem/" target="_blank"><i class="fa fa-facebook"></i></a></span></li>
                <li><span><a href="https://twitter.com/phoenixbinary" target="_blank"><i class="fa fa-instagram"></i></a></span></li>
				<li><span><a href="https://www.instagram.com/phoenixbinarysystem/" target="_blank"><i class="fa fa-twitter"></i></a></span></li>
            </ul>
        </div><!-- /tp-control -->
        <nav id="navbar" class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active"><a href="<?=file_path()?>home" class="a_font">Home</a></li>
                <li><a href="<?=file_path()?>about">About</a></li>
                <li><a href="<?=file_path()?>services">Services</a></li>
                <!--<li><a href="portfolio.html">Work</a></li>-->
               
                <li><a href="<?=file_path()?>contact">Contact</a></li>
            </ul>
        </nav><!--/.nav-collapse -->
    </div><!-- /main-nav-bar -->